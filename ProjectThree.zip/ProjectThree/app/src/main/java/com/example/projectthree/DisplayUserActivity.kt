package com.example.projectthree

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class DisplayUserActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_users) // Ensure this matches your XML layout file

        dbHelper = DatabaseHelper(this)
        listView = findViewById(R.id.listView)

        // Fetch all users from the database
        val users = dbHelper.getAllUsers()
        // Extract usernames
        val usernames = users.map { it.username }

        // Set up the ArrayAdapter with the list of usernames
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, usernames)
        listView.adapter = adapter
    }
}
