package com.example.projecttwo

import android.os.Bundle
import android.widget.Button
import android.widget.GridView
import androidx.appcompat.app.AppCompatActivity

class DataActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.data_activity)

        val addDataButton: Button = findViewById(R.id.addDataButton)
        val dataGrid: GridView = findViewById(R.id.dataGrid)

        // Implement adding and displaying data logic
    }
}
