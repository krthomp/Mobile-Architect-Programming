package com.example.projectthree

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "project_three.db"
        const val DATABASE_VERSION = 1

        // Items Table
        const val TABLE_NAME_ITEMS = "items"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "name"
        const val COLUMN_DESCRIPTION = "description"

        // Users Table
        const val TABLE_NAME_USERS = "users"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"

        // Create table queries
        private const val CREATE_TABLE_ITEMS = """
            CREATE TABLE $TABLE_NAME_ITEMS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_NAME TEXT NOT NULL,
                $COLUMN_DESCRIPTION TEXT NOT NULL
            )
        """

        private const val CREATE_TABLE_USERS = """
            CREATE TABLE $TABLE_NAME_USERS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT NOT NULL UNIQUE,
                $COLUMN_PASSWORD TEXT NOT NULL
            )
        """
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(CREATE_TABLE_ITEMS)
        db.execSQL(CREATE_TABLE_USERS)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME_ITEMS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME_USERS")
        onCreate(db)
    }

    // Items Table Methods
    fun insertItem(name: String, description: String): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_DESCRIPTION, description)
        }
        return db.insert(TABLE_NAME_ITEMS, null, values)
    }

    fun getItem(id: Long): Item? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME_ITEMS,
            arrayOf(COLUMN_ID, COLUMN_NAME, COLUMN_DESCRIPTION),
            "$COLUMN_ID = ?",
            arrayOf(id.toString()),
            null, null, null
        )

        return if (cursor.moveToFirst()) {
            val itemId = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
            val description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION))
            cursor.close()
            Item(itemId, name, description)
        } else {
            cursor.close()
            null
        }
    }

    fun getAllItems(): List<Item> {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME_ITEMS,
            arrayOf(COLUMN_ID, COLUMN_NAME, COLUMN_DESCRIPTION),
            null, null, null, null, null
        )

        val items = mutableListOf<Item>()
        while (cursor.moveToNext()) {
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
            val description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION))
            items.add(Item(id, name, description))
        }
        cursor.close()
        return items
    }

    fun updateItem(id: Long, name: String, description: String): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_DESCRIPTION, description)
        }
        return db.update(TABLE_NAME_ITEMS, values, "$COLUMN_ID = ?", arrayOf(id.toString()))
    }

    fun deleteItem(id: Long): Int {
        val db = this.writableDatabase
        return db.delete(TABLE_NAME_ITEMS, "$COLUMN_ID = ?", arrayOf(id.toString()))
    }

    // Users Table Methods
    fun insertUser(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        return db.insert(TABLE_NAME_USERS, null, values) != -1L
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME_USERS,
            arrayOf(COLUMN_USERNAME),
            "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?",
            arrayOf(username, password),
            null, null, null
        )
        val isValid = cursor.moveToFirst()
        cursor.close()
        return isValid
    }

    fun getAllUsers(): List<User> {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME_USERS,
            arrayOf(COLUMN_ID, COLUMN_USERNAME),
            null, null, null, null, null
        )

        val users = mutableListOf<User>()
        while (cursor.moveToNext()) {
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val username = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERNAME))
            users.add(User(id, username))
        }
        cursor.close()
        return users
    }
}
