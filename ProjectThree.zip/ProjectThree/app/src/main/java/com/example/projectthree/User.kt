package com.example.projectthree

data class User(
    val id: Long,
    val username: String
)
