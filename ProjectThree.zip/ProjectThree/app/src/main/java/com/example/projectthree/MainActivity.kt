package com.example.projectthree

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.GridView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var gridView: GridView
    private lateinit var addButton: Button
    private lateinit var showUsersButton: Button

    // Register for the SMS permission result
    private val smsPermissionRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            // Permission granted
            sendSMS("1234567890", "This is a test message.")
        } else {
            // Permission denied
            Toast.makeText(this, "SMS permission denied. SMS notifications will not be sent.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)
        gridView = findViewById(R.id.gridView)
        addButton = findViewById(R.id.addButton)
        showUsersButton = findViewById(R.id.showUsersButton)

        loadItems()

        addButton.setOnClickListener {
            val intent = Intent(this, AddItemActivity::class.java)
            startActivity(intent)
        }

        showUsersButton.setOnClickListener {
            val intent = Intent(this, DisplayUserActivity::class.java)
            startActivity(intent)
        }

        gridView.setOnItemClickListener { _, _, position, _ ->
            val item = dbHelper.getAllItems()[position]
            val intent = Intent(this, EditItemActivity::class.java).apply {
                putExtra("item_id", item.id)
            }
            startActivity(intent)
        }

        // Check for SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            sendSMS("1234567890", "This is a test message.")
        } else {
            // Request SMS permission
            smsPermissionRequest.launch(Manifest.permission.SEND_SMS)
        }
    }

    private fun loadItems() {
        val items = dbHelper.getAllItems()
        val adapter = CustomGridAdapter(this, items)
        gridView.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        loadItems()
    }

    private fun sendSMS(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(this, "SMS sent.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
