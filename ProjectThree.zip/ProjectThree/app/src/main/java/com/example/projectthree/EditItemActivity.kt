package com.example.projectthree

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditItemActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var nameEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var buttonUpdate: Button
    private lateinit var buttonDelete: Button
    private var itemId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_item)

        dbHelper = DatabaseHelper(this)
        nameEditText = findViewById(R.id.nameEditText)
        descriptionEditText = findViewById(R.id.descriptionEditText)
        buttonUpdate = findViewById(R.id.buttonUpdate)
        buttonDelete = findViewById(R.id.buttonDelete)

        itemId = intent.getLongExtra("item_id", -1)

        if (itemId != -1L) {
            loadItem()
        }

        buttonUpdate.setOnClickListener {
            updateItem()
        }

        buttonDelete.setOnClickListener {
            deleteItem()
        }
    }

    private fun loadItem() {
        val item = dbHelper.getItem(itemId)
        item?.let {
            nameEditText.setText(it.name)
            descriptionEditText.setText(it.description)
        }
    }

    private fun updateItem() {
        val name = nameEditText.text.toString().trim()
        val description = descriptionEditText.text.toString().trim()

        if (name.isNotEmpty() && description.isNotEmpty()) {
            val rowsAffected = dbHelper.updateItem(itemId, name, description)
            if (rowsAffected > 0) {
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteItem() {
        val rowsDeleted = dbHelper.deleteItem(itemId)
        if (rowsDeleted > 0) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show()
        }
    }
}
